package lab;

import java.io.*;
import java.util.*;

public class LabStore implements Serializable
{
    private ArrayList<ArrayList<Object[]>> allShapes   = new ArrayList<>(); //storing all serialized shapes

    public LabStore(){
        int noOfShapes = 5;

        for(int indexNo = 0; indexNo < noOfShapes; indexNo++){ //initialize an array of arrays
            this.allShapes.add(new ArrayList<Object[]>());
        }
    }


    public void shapeStore(Object[] shapeData, int index){  //index is shape type

        allShapes.get(index).add(shapeData); //store shapes

        ArrayList<Object[]> tmpArray = allShapes.get(index); //retrieve last saved for verification
        shapeData = tmpArray.get(tmpArray.size() -1);

        Display.showHeader(index);

        for(Object obj : shapeData){    //and print it
            System.out.print(obj + "\t\t");
        }

        System.out.println("\n");
    }


    public ArrayList<ArrayList<Object[]>> allSend(){return allShapes;}

    public void shapeDisplay(ArrayList<Object[]> allShapes, String option){

        switch (option){
            case "r":
                System.out.format("Printing Rectangles\n");
                break;
            case "c":
                System.out.format("Printing Circles\n");
                break;
            case "t":
                System.out.format("Printing Triangles\n");
                break;
            case "a":
                System.out.format("Printing Shapes\n");
                break;
            default:
                break;
        }
        
        for(Object[] objA : allShapes){ //loop through array of objects
            for(Object obj : objA) {    //loop through elements in object[]
                System.out.print(obj + " "); //recall saved values and print
            }
        }
        System.out.println();
    }


}
