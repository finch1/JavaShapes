package lab;

public class LabShapes3D extends LabShapes implements Volume{

    int numSides;
    String name;

    double threeDPer;
    double threeDArea;
    double threeDVol;



    public LabShapes3D(String name, int numSides){
        super(name, numSides);
        this.name = name;
        this.numSides = numSides;
    }


    public int getNumSides(){
        return numSides;
    }

    public String getName(){
        return name;
    }

    public double getPerimeter(){return threeDPer;}

    public double getArea(){return threeDArea;}

    public double getVolume(){return threeDVol;}

    public Object[] toArray(){return  new Object[]{};}

}
