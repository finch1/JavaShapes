package lab;

import java.util.Scanner;

public class LabMain {

    public static void main(String[] args) {

        //start of program
        LabMenu obj = new LabMenu();
        obj.displayMenu();

    }
}