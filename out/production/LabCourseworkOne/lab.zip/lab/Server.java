package lab;

        import java.lang.*;
        import java.io.*;
        import java.net.*;

class Server {

    public static void main(String args[]) {
        new Server();
    }

    public Server(){
        ServerSocket srvr = null;
        int clientNo = 0;// Number a client

        try {
            srvr = new ServerSocket(1234);
            System.out.print("Server Waiting...\n");

            while(true){
                Socket skt = srvr.accept();
                System.out.println("Server has connected!");
                System.out.println("You are Client No: " + clientNo);
                Thread sc = new ServerConnection(skt);
                clientNo = Thread.activeCount(); // Increment clientNo
                sc.start();
            }

        }
        catch(Exception e) {
            System.out.print("Whoops! It didn't work!\n");
            e.printStackTrace();
        }
        finally {
            if (srvr != null) {
                try {
                    srvr.close();
                } //try
                catch (IOException e) {
                    // log error just in case
                } //catch
            }//if
        }//finally
    }

}//server class