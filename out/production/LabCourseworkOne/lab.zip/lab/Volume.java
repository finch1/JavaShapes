package lab;

public interface Volume {

    double getVolume();
}

