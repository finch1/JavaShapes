
package lab;

import java.util.InputMismatchException;
import java.util.Scanner;

public class LabMenu extends Thread{


    final static String[] mainMenu = {"1 - 2D shapes", "2 - 3D shapes", "3 - Exit"}; //type content

    final static String[] menu2D = {"1 - Rectangle", "2 - Circle", "3 - Triangle", "4 - Send shapes created", "5 - Receive Shapes", "6 - Back to main"};   //menu 2D content

    final static String[] menu3D = {"1 - Cylinder", "2 - Sphere", "3 - Send shapes created", "5 - Receive Shapes", "6 - Back to main"};     //menu 3D content

    final static String[] menuRX = {"r - Rectangle", "c - Circle", "t - Triangle", "a - All"};     //menu receive options


    LabStore storeShapes = new LabStore();

    Scanner console = new Scanner(System.in);

    String fileName;



    public void displayMenu() { //output menus + user input


        int keyVal = 0; //storing user input to check default
        String charVal = null; //storing user input to check default

        while (true) { //loop menu until user exit

            System.out.println("Choose by typing a number:");


            for (String s : mainMenu) { //display main menu options
                System.out.println(s);
            }

            //main menu
            keyVal = listenForInput();
            switch (keyVal){
                case 1: //2D shapes
                    System.out.println("Choose by typing a number:");

                    for (String s : menu2D) { //display options
                        System.out.println(s);
                    }

                    keyVal = listenForInput();
                    switch (keyVal){
                        case 1: //rectangle
                            clientRectange();
                            break;

                        case 2: //circle
                            clientCircle();
                            break;

                        case 3: //triangle
                            clientTriangle();
                            break;

                        case 4: //TX
                                System.out.print("Enter a filename: ");
                                fileName = getString();
                                new LabClient(storeShapes.allSend(),1, fileName);//transfer over network
                            break;

                        case 5: //RX
                            System.out.println("Choose option by typing a letter:");

                            //display options
                            for (String s : menuRX) {
                                System.out.println(s);
                            }

                            charVal = listenForKey();

                            switch (charVal)
                            {
                                case "r":
                                    if(fileName != null) {
                                        System.out.print("Use last file name: " + fileName + "?\ny - yes\nn - no\n");
                                        charVal = listenForKey();

                                        if (charVal == "n") {
                                            System.out.print("Enter a filename: ");
                                            fileName = getString();
                                        }
                                    }
                                    else {
                                        System.out.print("Enter a filename: ");
                                        fileName = getString();
                                    }

                                    new LabClient(2, fileName, "r");//transfer over network

                                    break;
                                case "c":
                                    new LabClient(3, fileName,"c");//transfer over network
                                    break;
                                case "t":
                                    new LabClient(4, fileName,"t");//transfer over network
                                    break;
                                case "a":
                                    new LabClient(5, fileName,"a");//transfer over network
                                    break;
                                default:
                                    System.out.println("value must be between 1 and 6\n");
                                    break;
                            }


                            break;

                        case 6: //sub-exit
                            System.out.println("To main menu");
                            break; //exit

                        default:
                                System.out.println("value must be between 1 and 6\n");
                            break;
                    }//2D switch
                    break; //case 1 main menu

                case 2: //3D shapes
                    System.out.println("Choose by typing a number:");

                    for (String s : menu3D) { //display options
                        System.out.println(s);
                    }

                    keyVal = listenForInput();

                    switch (keyVal) {
                        case 1: //sphere
                            break;

                        case 2: //cylinder
                            break;

                        case 3: //TX
                            break;

                        case 4: //RX
                            break;

                        default:
                            if(keyVal < 0 || keyVal > 4)//out of range
                            {
                                System.out.println("Input value out of range");
                                break;
                            }
                    }//3D switch
                    break;//3D Case

                case 3:
                    System.out.println("Bye!!"); //exit main menu
                    System.exit(0);
                    break; //exit

                default:
                    System.out.println("value must be between 1 and 3\n");
                    break;
            }//switch

        }//while
    }//run

    private int listenForInput(){
        int keyVal = 0;

        try{ //wait for user input + catch exception
            keyVal = console.nextInt();
        }
        catch (InputMismatchException ime){
            System.out.println("NaN!!");
            console.next();
        }

        return keyVal;
    }

    private String listenForKey(){
        String keyVal = null;

        try{ //wait for user input + catch exception
            keyVal = console.next();
        }
        catch (InputMismatchException ime){
            System.out.println("NaL!!");
            console.next();
        }

        return keyVal;
    }

    private String getString(){
        String input = null;

        //listen for input from user
        Scanner console = new Scanner(System.in);

        try{
            input = console.nextLine();//pull user choice
        }
        catch(InputMismatchException ime) {
            System.out.println("Your input is invalid, please try again\n");
            console.next();
        }

        return input;
    }

    private double getShapeValue(){
        double input = 0;

        //listen for input from user
        Scanner console = new Scanner(System.in);
        while(true){
            try{
                input = console.nextDouble();//pull user choice
                return input;
            }
            catch(InputMismatchException ime) {
                System.out.print("Your input is invalid, please enter the number again: ");
                console.next();
            }
}


    }

    private void clientRectange(){

        LabRect2D myRect = null;

        //ask user for necessary input
        System.out.print("Rectangle name: ");
        String name = getString();

        System.out.print("Rectangle width: ");
        double recWidth = getShapeValue(); //scan.nextDouble();

        System.out.print("Rectangle height: ");
        double recHeight = getShapeValue();

        //initializing new object of type LabRect2D + save object with data
        myRect = new LabRect2D(name, recWidth, recHeight);
        storeShapes.rectStore(myRect.toArray());
    }

    private void clientCircle(){

        LabCrcl2D myCrcl = null;

        //ask user for necessary input
        System.out.print("Circle name: ");
        String name = getString();

        System.out.print("Circle radius: ");
        double crclRadius = getShapeValue(); //scan.nextDouble();

        //initializing new object of type LabRect2D + save object with data
        myCrcl = new LabCrcl2D(name, crclRadius);
        storeShapes.crclStore(myCrcl.toArray());
    }

    private void clientTriangle(){

        LabTri2D myTri = null;

        //ask user for necessary input
        System.out.print("Triangle name: ");
        String name = getString();

        System.out.print("Triangle base: ");
        double triBase = getShapeValue(); //scan.nextDouble();

        System.out.print("Triangle height: ");
        double triHeight = getShapeValue(); //scan.nextDouble()

        //initializing new object of type LabRect2D + save object with data
        myTri = new LabTri2D(name, triBase, triHeight);
        storeShapes.triStore(myTri.toArray());
    }

}//LabMenu







