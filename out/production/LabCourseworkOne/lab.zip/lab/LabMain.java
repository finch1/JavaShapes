package lab;

import java.util.Scanner;

public class LabMain {

    public static void main(String[] args) {

        //begin execution
//        Thread shapeInterface = new LabMenu();
//        shapeInterface.start();

        LabMenu obj = new LabMenu();
        obj.displayMenu();

    }
}