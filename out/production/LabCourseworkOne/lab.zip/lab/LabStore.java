package lab;

import java.io.*;
import java.util.*;

public class LabStore implements Serializable
{
    private ArrayList<ArrayList<Object[]>> allShapes   = new ArrayList<>(); //storing all serialized shapes

    private ArrayList<Object[]> onlyRect    = new ArrayList<Object[]>(); //store type rectangle
    private ArrayList<Object[]> onlyCrcl    = new ArrayList<Object[]>(); //store type circle
    private ArrayList<Object[]> onlyTri     = new ArrayList<Object[]>(); //store type triangle
    private ArrayList<Object[]> onlyCyl     = new ArrayList<Object[]>(); //store type Cylinder
    private ArrayList<Object[]> onlySphr    = new ArrayList<Object[]>(); //store type Sphere

    public LabStore(){
        this.allShapes.add(onlyRect);
        this.allShapes.add(onlyCrcl);
        this.allShapes.add(onlyTri);
        this.allShapes.add(onlyCyl);
        this.allShapes.add(onlySphr);
    }

    public void rectStore(Object[] aRect){

        onlyRect.add(aRect); //add object to array
        aRect = onlyRect.get(onlyRect.size() -1); //recall saved values and print
        System.out.format("\nSaved %s, %.2f by %.2f\n\n", aRect[0], aRect[1], aRect[2]);
    }


    public void crclStore(Object[] aCrcl){

        onlyCrcl.add(aCrcl); //add object to array
        aCrcl = onlyCrcl.get(onlyCrcl.size() -1); //recall saved values and print
        System.out.format("\nSaved %s, %.2f\n\n", aCrcl[0], aCrcl[1]);
    }



    public void triStore(Object[] aTri){

        onlyTri.add(aTri); //add object to array
        aTri = onlyTri.get(onlyTri.size() -1); //recall saved values and print
        System.out.format("\nSaved %s, %.2f by %.2f\n\n", aTri[0], aTri[1], aTri[2]);
    }


    public void CylStore(Object[] aCyl){

        onlyCyl.add(aCyl); //add object to array
        aCyl = onlyCyl.get(onlyCyl.size() -1); //recall saved values and print
        System.out.format("Saved %s, %.2f by %.2f\n", aCyl[0], aCyl[1], aCyl[2]);
    }


    public void SphrStore(Object[] aSphr){
        onlySphr.add(aSphr); //add object to array
        aSphr = onlySphr.get(onlySphr.size() -1); //recall saved values and print
        System.out.format("Saved %s, %.2f\n", aSphr[0], aSphr[1]);
    }




    public ArrayList<ArrayList<Object[]>> allSend(){return allShapes;}

    public void shapeDisplay(ArrayList<Object[]> allShapes, String option){

        switch (option){
            case "r":
                System.out.format("\nPrinting Rectangles\n");
                for(Object[] objRect : allShapes){
                    System.out.format("\nGot back %s, %.2f by %.2f", objRect[0], objRect[1], objRect[2]);//recall saved values and print
                }
                System.out.println();
                break;
            case "c":
                break;
            case "t":
                break;
            case "a":
                break;
            default:
                break;

        }

    }


}
