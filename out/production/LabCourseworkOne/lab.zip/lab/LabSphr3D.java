package lab;

public class LabSphr3D extends LabShapes3D {

    private double sphrRadius;
    private String sphrName;

    private double sphrArea;


    public LabSphr3D(String sphrName, double sphrRadius){
        super(sphrName, 1);
        this.sphrName = sphrName;
        this.sphrRadius = sphrRadius;
        this.getArea();
    }


    @Override
    protected double getArea(){
        sphrArea =  4 * Math.PI * (sphrRadius * sphrRadius);
        return  sphrArea;
    }


    public double setRadius(){ return this.sphrRadius;}


}
