package lab;

import java.io.*;
import java.net.*;
import java.nio.*;
import java.util.*;


//handle connection
public class ServerConnection extends Thread{
    Socket socket = null;

    DataInputStream din = null;
    DataOutputStream dout = null;
    ObjectInputStream serverIn = null;
    ObjectInputStream fileIn = null;
    ObjectOutputStream fileOut = null;
    ObjectOutputStream objOut = null;
    FileOutputStream toFile = null;
    FileInputStream fromFile = null;

    ArrayList<ArrayList<Object[]>> myObjArr = new ArrayList<ArrayList<Object[]>>();
    ArrayList<ArrayList<Object[]>> myTmpArr = new ArrayList<ArrayList<Object[]>>();

    public ServerConnection(Socket socket){
        super("ServerConnectionThread");
        this.socket = socket;
    }


    public void run(){
        try {
                din = new DataInputStream(socket.getInputStream()); //get instruction
                dout = new DataOutputStream(socket.getOutputStream()); //inform client

                int keyVal = din.readInt(); System.out.println("Instr: " + keyVal);

                switch(keyVal){
                    case 1://1 store array of shapes from client;
                        storeArrayToFile();
                        break;

                    case 2://2 send Rec;
                        sendRectangle();
                        break;

                    case 3://3 send Cir;
                        objOut.writeObject(myObjArr.get(1));
                        break;

                    case 4://4 send Tri;
                        objOut.writeObject(myObjArr.get(2));
                        break;

                    case 5://5 send all
                        objOut.writeObject(myObjArr);
                        break;

                    default:
                        dout.writeBytes("something went bust!!");//something went wong, sent to client
                        break;
            }//switch

        }//try
        catch (IOException e) {
            e.printStackTrace();
        }//catch
        finally{
            try {
                if (din != null) {din.close(); System.out.println("din.close");}
                if (dout != null) {dout.close(); System.out.println("dout.close");}
                if (socket != null) {socket.close(); System.out.println("socket.close");}
                if (serverIn != null) {serverIn.close(); System.out.println("serverIn.close");}
                if (fileOut != null) {fileOut.close(); System.out.println("fileOut.close");}
                if (objOut != null) {objOut.close(); System.out.println("objOut.close");}
                if (toFile != null) {toFile.close(); System.out.println("toFile.close");}
            }catch (IOException e) {
                e.printStackTrace();
            }
        }//finally
    }//run

    private void storeArrayToFile(){
        try {
            String fileName = din.readUTF();
            File clientFile = new File(fileName + ".txt");
            System.out.println("File Name: " + clientFile.getPath());

            if(clientFile.exists()){ //append
                dout.writeUTF("\nFile already exists!!\n");
                dout.writeInt(1);
                dout.flush();

                //try again with file
                int keyVal = din.readInt();
                if( keyVal == 1){//append true

                    //get array from socket
                    serverIn = new ObjectInputStream(socket.getInputStream()); //get object stream
                    myTmpArr = (ArrayList<ArrayList<Object[]>>) serverIn.readObject(); //deserialize
                    dout.writeUTF("\nData shall be appended!!\n");

                    //read file
                    fromFile = new FileInputStream(clientFile);
                    fileIn = new ObjectInputStream(fromFile);
                    myObjArr = (ArrayList<ArrayList<Object[]>>) fileIn.readObject();

                    //combine arrays + iterate through all five
                    //ArrayList<Object[]> onlyRect = myObjArr.get(0);
                    //ArrayList<Object[]> tempRect = myTmpArr.get(0);
                    //onlyRect.addAll(tempRect);

                    myObjArr.get(0).addAll(myTmpArr.get(0));


                    //write to file
                    toFile = new FileOutputStream(clientFile); //save to new file
                    fileOut = new ObjectOutputStream(toFile); //write to the new file


                    fileOut.writeObject(myObjArr);

                    System.out.print("OK got it and saved!!\n");
                    fileOut.flush(); //write everything to file
                    toFile.close();  //close file
                }

                if( keyVal == 2){//overwrite
                    dout.writeUTF("\nData shall be overwritten!!\n");
                    toFile = new FileOutputStream(clientFile, false); //save to new file
                    serverIn = new ObjectInputStream(socket.getInputStream()); //get object stream
                    fileOut = new ObjectOutputStream(toFile); //write to the new file

                    Object object = serverIn.readObject(); //deserialize
                    fileOut.writeObject(object);
                    myObjArr = (ArrayList<ArrayList<Object[]>>) object;
                    System.out.print("OK got it and saved!!\n");
                    fileOut.flush(); //write everything to file
                    toFile.close();  //close file
                }

                if( keyVal == 3){//call file method again
                    storeArrayToFile();
                }
            }
            else{ //write to a new file name
                dout.writeUTF("\nData saved!!\n");
                dout.writeInt(0);

                serverIn = new ObjectInputStream(socket.getInputStream()); //get object stream
                Object object = serverIn.readObject();//read from server

                toFile = new FileOutputStream(clientFile); //save to new file
                fileOut = new ObjectOutputStream(toFile); //write to the new file
                fileOut.writeObject(object);

                myObjArr = (ArrayList<ArrayList<Object[]>>) object; //this is only if user stays logged in
                System.out.print("OK got it and saved!!\n");

                fileOut.flush(); //write everything to file
                fileOut.close();
                toFile.close();  //close file
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }


    }

    private void sendRectangle(){
        try {
            String fileName = din.readUTF();
            File clientFile = new File(fileName + ".txt");

            if(clientFile.exists()){
                //load file
                fromFile = new FileInputStream(clientFile); //read from file
                fileIn = new ObjectInputStream(fromFile); //get object stream
                //file to big array
                myObjArr = (ArrayList<ArrayList<Object[]>>) fileIn.readObject();
                //array element to serialize
                //out to socket
                objOut = new ObjectOutputStream(socket.getOutputStream()); //write object to client
                objOut.writeObject(myObjArr.get(0));
                objOut.flush(); //write everything to file
                fromFile.close();  //close file
                System.out.print("Rectangle list sent over!!\n");

            }
            else{
                dout.writeUTF("Sorry file name not found!!\n\n");
                dout.flush();


            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }

}//Thread

